<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BaiHat extends Model
{
    //
   	protected $table = "BaiHat";
   	protected $primaryKey = "maBaiHat";
   	//public $timestamps = false;
   	public function quocgia()
	{
		return $this->belongsTo('App\QuocGia','maQuocGia');
	}
	public function nguoidung()
	{
		return $this->belongsTo('App\User','id');
	}
	public function casy()
	{
		return $this->belongsTo('App\CaSy','maCaSy');
	}
	public function casy2()
	{
		return $this->belongsTo('App\CaSy','maCaSy2');
	}
	public function nhacsi()
	{
		return $this->belongsTo('App\NhacSi','maNhacSi');
	}
	public function chude()
	{
		return $this->belongsTo('App\ChuDe','maChuDe');
	}
	public function theloai()
	{
		return $this->belongsTo('App\theloais','maTheLoai');
	}
	public function chatluong()
	{
		return $this->belongsTo('App\ChatLuong','maChatLuong');
	}
	public function binhluan()
	{
		return $this->hasMany('App\BinhLuan','maBaiHat');
	}
	public function download()
	{
		return $this->hasOne('App\Tai','id');
	}
}
