<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChuDe extends Model
{
    //
    protected $table = "ChuDe";
    protected $primaryKey ="maChuDe";
}
