<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BinhLuan extends Model
{
    //
    protected $table = "BinhLuan";
    protected $primaryKey = "idBL";
    public $timestamps = false;
    public function user()
	{
		return $this->belongsTo('App\User','id');
	}
	public function baihat()
	{
		return $this->belongsTo('App\BaiHat','maBaiHat');
	}
}
