<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tai extends Model
{
    //
    protected $table = "Tai";
    public $timestamps = false;
    public function user()
	{
		return $this->belongsTo('App\User','id');
	}
	public function baihat()
	{
		return $this->belongsTo('App\BaiHat','maBaiHat');
	}
}
