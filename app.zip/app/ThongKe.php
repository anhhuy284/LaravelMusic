<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ThongKe extends Model
{
    //
    protected $table = "Luot";
    protected $primaryKey = "idLuot";
    //public $timestamps = false;
    
   	public function baihat(){
   		return $this->belongsTo('App\BaiHat','idLuot','maBaiHat');
   	}
}
