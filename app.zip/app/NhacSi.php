<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NhacSi extends Model
{
    //
	protected $table = "NhacSi";
	protected $primaryKey = "maNhacSi";
}
