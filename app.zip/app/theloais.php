<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class theloais extends Model
{
    //
    protected $table = "TheLoai";
    protected $primaryKey = "maTheLoai";
    public $timestamps = false;
	public function quocgia(){
    	return $this->belongsTo('App\QuocGia','maQuocGia');
    }
   	public function baihat(){
   		return $this->hasMany('App\BaiHat','maTheLoai','maBaiHat');
   	}
}
