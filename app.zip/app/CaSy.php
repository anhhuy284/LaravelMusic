<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CaSy extends Model
{
    //
    protected $table = "CaSy";
    protected $primaryKey = "maCaSy";
	public function baihat()
	{
		return $this->hasMany('App\BaiHat','maCaSy');
	}
}
