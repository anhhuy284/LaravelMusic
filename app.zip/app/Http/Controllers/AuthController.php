<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
//use Illuminate\Support\Facades\Route;
//use Illuminate\Routing\Route;

class AuthController extends Controller
{
    //
    public function login(Request $request)
    {
    	echo $request['username']."<br>";
    	echo $request['password'];
    /*	$username = $request['username'];
    	$password = $request['password'];
    	if(Auth::attempt(['name'=>$username,'password'=>$password]))
    		return view('thanhcong');
    	else
    		return view('dangnhap');*/
    }
}
