<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\BinhLuan;
use App\User;
use App\BaiHat;
use Auth;

class BinhLuanController extends Controller
{
    //
    function __construct(){
        $binhluan = BinhLuan::all();
        $baihat = BaiHat::all();
        $user = User::all();
        view()->share('baihat',$baihat);view()->share('user',$user);view()->share('binhluan',$binhluan);
    }
    public function getDanhSach(){
    	return view('admin.binhluan.danhsach');
    }
    public function getSua(){
    	return view('admin.binhluan.sua');	
    }
    public function getXoa($id){
    	$binhluan = BinhLuan::find($id);

    	$binhluan->delete();
    	return redirect('admin/binhluan/danhsach')->with('thongbao','Đã xóa');	
    }
    public function postBinhLuan($id, Request $request){
    	$idBaiHat = $id;

        
    	$baihat = BaiHat::find($id);
    	$binhluan = new BinhLuan;
    	$binhluan->maBaiHat = $idBaiHat;
    	$binhluan->id = Auth::user()->id;
    	if(is_null($request->NoiDung)){
    		return redirect("baihat/$id/".$baihat->tenKhongDau.".html")->with('loiBL','Bạn chưa viết bình luận');	
    	}
    	$binhluan->noiDung = $request->NoiDung;
    	$binhluan->ngayBL = $request->ngayBL;

    	$binhluan->save();
    	return redirect("baihat/$id/".$baihat->tenKhongDau.".html")->with('thongbaoBL','Cảm ơn bạn đã để lại lời bình luận. Chúc bạn nghe nhạc vui vẻ.');
    }

}
