<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\ChuDe;

class ChuDeController extends Controller
{
    //
    public function getDanhSach(){
        $chude = ChuDe::all();
    	return view('admin.chude.danhsach',['chude'=>$chude]);
    }
    
    public function getThem(){
    	return view('admin.chude.them');	
    }
    public function postThem(Request $request){
        $this->validate($request,
            [
                'Ten' => 'required|unique:ChuDe,tenChuDe|min:3|max:100'
            ],
            [
                'Ten.required'=>'Bạn chưa nhập tên chủ đề',
                'Ten.unique'=>'Chủ đề đã tồn tại',
                'Ten.min'=>'Chủ đề phải có độ dài từ 3 => 100 ký tự',
                'Ten.max'=>'Chủ đề phải có độ dài từ 3 => 100 ký tự'
            ]);
        $chude = new ChuDe;

        $chude->tenChuDe = $request->Ten;
        $chude->tenKhongDau =  changeTitle($request->Ten);

        $chude->save();
        return redirect('admin/chude/them')->with('thongbao','Thêm thành công');
    }

    public function getSua($id){
        $chude = ChuDe::find($id);
    	return view('admin.chude.sua',['chude'=>$chude]);	
    }

    public function postSua(Request $request,$id){
        $chude = ChuDe::find($id);
        $this->validate($request,
            [
                'Ten' => 'required|unique:ChuDe,tenChuDe|min:3|max:100'
            ],
            [
                'Ten.required'=>'Bạn chưa nhập tên chủ đề',
                'Ten.unique'=>'Chủ đề đã tồn tại',
                'Ten.min'=>'Tên chủ đề phải có độ dài từ 3 => 100 ký tự',
                'Ten.max'=>'Tên chủ đề phải có độ dài từ 3 => 100 ký tự'
            ]);
        $chude->tenChuDe = $request->Ten;
        $chude->tenKhongDau =  changeTitle($request->Ten);
        
        $chude->save();

        return redirect('admin/chude/sua/'.$id)->with('thongbao','Sửa thành công');
    }

    public function getXoa($id){
        $chude = ChuDe::find($id);
        $chude->delete();

        return redirect('admin/chude/danhsach')->with('thongbao','Xóa thành công');
    }
}
