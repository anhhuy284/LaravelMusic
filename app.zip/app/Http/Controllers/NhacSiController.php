<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\NhacSi;

class NhacSiController extends Controller
{
    //
     public function getDanhSach(){
        $nhacsi = NhacSi::all();
    	return view('admin.nhacsi.danhsach',['nhacsi'=>$nhacsi]);
    }
    public function getThem(){
    	return view('admin.nhacsi.them');	
    }
    public function postThem(Request $request){
        $this->validate($request,
            [
                'Ten' => 'required|unique:NhacSi,tenNhacSi|min:3|max:100'
            ],
            [
                'Ten.required'=>'Bạn chưa nhập tên nhạc sĩ',
                'Ten.unique'=>'Nhạc sĩ đã tồn tại',
                'Ten.min'=>'Nhạc sĩ phải có độ dài từ 3 => 100 ký tự',
                'Ten.max'=>'Nhạc sĩ phải có độ dài từ 3 => 100 ký tự'
            ]);
        $nhacsi = new NhacSi;

        $nhacsi->tenNhacSi = $request->Ten;
        $nhacsi->tenKhongDau =  changeTitle($request->Ten);

        $nhacsi->save();
        return redirect('admin/nhacsi/them')->with('thongbao','Thêm thành công');
    }
    public function getSua($id){
        $nhacsi = NhacSi::find($id);
    	return view('admin.nhacsi.sua',['nhacsi'=>$nhacsi]);	
    }
    public function postSua(Request $request,$id){
        $nhacsi = NhacSi::find($id);
        $this->validate($request,
            [
                'Ten' => 'required|unique:NhacSi,tenNhacSi|min:3|max:100'
            ],
            [
                'Ten.required'=>'Bạn chưa nhập tên nhạc sĩ',
                'Ten.unique'=>'Nhạc sĩ đã tồn tại',
                'Ten.min'=>'Tên nhạc sĩ phải có độ dài từ 3 => 100 ký tự',
                'Ten.max'=>'Tên nhạc sĩ phải có độ dài từ 3 => 100 ký tự'
            ]);
        $nhacsi->tenNhacSi = $request->Ten;
        $nhacsi->tenKhongDau =  changeTitle($request->Ten);

        $nhacsi->save();
        return redirect('admin/nhacsi/sua/'.$id)->with('thongbao','Sửa thành công');
    }

    public function getXoa($id){
        $nhacsi = NhacSi::find($id);
        $nhacsi->delete();

        return redirect('admin/nhacsi/danhsach')->with('thongbao','Xóa thành công');
    }
}
