<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\User;
use App\theloais;
use App\QuocGia;
use App\ChuDe;
use App\Slide;
use App\BaiHat;
use App\CaSy;
use App\ChatLuong;
use App\NhacSi;
use App\Tai;
use App\BinhLuan;
use App\ThongKe;

class CaSyController extends Controller
{
    //
     function __construct(){
        
        $download = Tai::all();
        view()->share('download',$download);
        $quocgia = QuocGia::all();
        view()->share('quocgia',$quocgia);
        $chude = ChuDe::all();
        view()->share('chude',$chude);
        $theloai = theloais::all();
        view()->share('theloai',$theloai);
        $chatluong = ChatLuong::all();
        view()->share('chatluong',$chatluong);
        $casy = CaSy::all();
        view()->share('casy',$casy);
        $NhacSi = NhacSi::all();
        view()->share('NhacSi',$NhacSi);
        $baihat = BaiHat::all();
        view()->share('baihat',$baihat);
        $thongke = ThongKe::all();
        view()->share('thongke',$thongke);
        $bxh = BaiHat::orderBy('luotNghe','desc')->get()->take(10);
        view()->share('bxh',$bxh);
    }
    public function getDanhSach(){
        $casy = CaSy::all();
        $baihat = BaiHat::all();
    	return view('admin.casy.danhsach',['casy'=>$casy,'baihat'=>$baihat]);
    }
    public function getThem(){
        $casy = CaSy::all();
    	return view('admin.casy.them',['casy'=>$casy]);	
    }
    public function postThem(Request $request){
        $this->validate($request,
            [
                'Ten' => 'required|unique:CaSy,tenCaSy|min:3|max:100',
                
            ],
            [
                'Ten.required'=>'Bạn chưa nhập tên ca sỹ',
                'Ten.unique'=>'Ca sỹ đã tồn tại',
                'Ten.min'=>'Tên ca sỹ phải có độ dài từ 3 => 100 ký tự',
                'Ten.max'=>'Tên ca sỹ phải có độ dài từ 3 => 100 ký tự',
            ]);
        $casy = new CaSy;

        $casy->tenCaSy = $request->Ten;
        $casy->ngheDanh = $request->NgheDanh;
        $quoctich = QuocGia::find($request->QuocGia);
            $casy->quocTich=$quoctich->tenQuocGia;    
            $casy->maQuocGia=$quoctich->maQuocGia;
        $casy->gioiTinh = $request->gt;

        if($request->thang!=null&&$request->ngay!=null){
            if(is_null($request->nam)){
                $casy->ngaySinh = $request->ngay."-".$request->thang;    
            }
            else
            {
                $casy->ngaySinh = $request->ngay."-".$request->thang."-".$request->nam;
            }
        }
        else{
                $casy->ngaySinh = $request->nam;    
            }
        if($request->hasFile('Hinh'))
        {
            $file = $request->file('Hinh');
            $duoi = $file->getClientOriginalExtension();
            if($duoi != 'jpg' && $duoi != 'png' && $duoi != 'jpeg'){
                return redirect('admin/casy/them')->with('loi','File ảnh không đúng định dạng jpg|png|jpeg.');
            }
            $name = $file->getClientOriginalName();
            $Hinh = str_random(4)."_".$name;
            while(file_exists("upload/hinhCaSy/".$Hinh)){
                $Hinh = str_random(4)."_".$duoi;
            }
            $file->move("upload/hinhCaSy",$Hinh);
            $casy->hinhAnh = $Hinh;
        }
        else
        {
            $casy->hinhAnh = "";
        }
        if($request->TieuSu=="")
            $casy->tieuSu = "Đang cập nhật";    
        else
            $casy->tieuSu = $request->TieuSu;
        $casy->tenKhongDau =  changeTitle($request->Ten);

        $casy->save();
        return redirect('admin/casy/danhsach')->with('thongbao','Thêm thành công ca sỹ '.$casy->tenCaSy);
    }
    public function getSua($id){
        $casy = CaSy::find($id);
    	return view('admin.casy.sua',['casy'=>$casy]);
    }
    public function postSua(Request $request,$id){
        $casy = CaSy::find($id);
        
        $casy->tenCaSy=$request->Ten;

        $quoctich = QuocGia::find($request->QuocGia);
            $casy->quocTich=$quoctich->tenQuocGia;    
            $casy->maQuocGia=$quoctich->maQuocGia;    
        $casy->ngheDanh=$request->ngheDanh;
        if($request->thang!=null&&$request->ngay!=null){
            if(is_null($request->nam)){
                $casy->ngaySinh = $request->ngay."-".$request->thang;    
            }
            else
            {
                $casy->ngaySinh = $request->ngay."-".$request->thang."-".$request->nam;
            }
        }
        else{
                $casy->ngaySinh = $request->nam;    
            }
        if($request->hasFile('Hinh'))
        {
            if(file_exists("upload/hinhCasy/".$casy->hinhAnh)){
                unlink("upload/hinhCasy/".$casy->hinhAnh);
            }
            $file = $request->file('Hinh');
            $duoi = $file->getClientOriginalExtension();
            if($duoi != 'jpg' && $duoi != 'png' && $duoi != 'jpeg'){
                return redirect('admin/casy/sua/'.$id)->with('loi','File ảnh không đúng định dạng jpg|png|jpeg.');
            }
            
            $name = $file->getClientOriginalName();
            $Hinh = str_random(4)."_".$name;
            while(file_exists("upload/hinhCaSy/".$Hinh)){
                $Hinh = str_random(4)."_".$name;
            }
            
            $file->move("upload/hinhCaSy",$Hinh);
            $casy->hinhAnh = $Hinh;
        }
        $casy->tenKhongDau =  changeTitle($request->Ten);
        $casy->gioiTinh = $request->gt;
        $casy->tieuSu = $request->TieuSu;

        $casy->save();
        return redirect('admin/casy/sua/'.$id)->with('thongbao','Sửa thành công');
    }

    public function getXoa($id){
        $casy = CaSy::find($id);
        if(file_exists("upload/hinhCasy/".$casy->hinhAnh)){
                unlink("upload/hinhCasy/".$casy->hinhAnh);
        }
        $casy->delete();

        return redirect('admin/casy/danhsach')->with('thongbao','Xóa thành công');
    }

}
