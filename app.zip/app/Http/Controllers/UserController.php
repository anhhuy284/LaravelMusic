<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

use App\Http\Requests;
use Auth;
use App\User;

class UserController extends Controller
{
    public function getDanhSach(){
        $user= User::all();
    	return view('admin.user.danhsach',['user'=>$user]);
    }
    public function getThem(){
        $user = User::all();
        return view('admin.user.them',['user'=>$user]);
    }
    public function postThem(Request $request){
        $this->validate($request,
            [
                'name' => 'required|unique:users,username|min:6|max:30',
                'pwd' => 'required|min:6|max:30',
                'pwdAgain' => 'required|same:pwd',
                'Email' => 'required|email|unique:users,email'
            ],
            [
                'name.required'=>'Bạn chưa nhập Username',
                'name.unique'=>'User đã tồn tại',
                'name.min'=>'Username phải có ít nhất 6 ký tự',
                'name.max'=>'Username tối đa 30 ký tự',
                'pwd.required'=>'Bạn chưa nhập password',
                'pwd.min'=>'Password phải có ít nhất 6 ký tự',
                'pwd.max'=>'Password tối đa 30 ký tự',
                'pwdAgain.required' =>'Bạn chưa nhập password xác nhận',
                'pwdAgain.same' =>'Password xác nhận không đúng',
                'Email.required'=>'Bạn chưa nhập email',
                'Email.email'=>'Email không đúng. Vui lòng kiểm tra lại',
                'Email.unique'=>'Email đã được sử dụng. Vui lòng dùng địa chỉ Email khác'
            ]);
        $user = new User;

        $user->username = $request->name;
        $user->password = bcrypt($request->pwd);
        $user->email = $request->Email;
        $user->name = $request->Ten;
        $user->level = $request->loaiUser;

        $user->save();
        return redirect('admin/user/them')->with('thongbao','Thêm thành công');
    }

    public function getSua($id){
    	$user = User::find($id);
    	return view('admin.user.sua',['user'=>$user]);
    }
    public function postSua(Request $request,$id){
    	$user = User::find($id);

    	$user->name = $request->Ten;
    	$user->level = $request->loaiUser;
        if($request->changePwd == "on"){
            $this->validate($request,[
                    'pwdNew' => 'required|min:6|max:30',
                    'pwdAgain' => 'required|same:pwdNew',
                ],[
                    'pwdNew.required'=>'Bạn chưa nhập mật khẩu mới',
                    'pwdNew.min'=>'Mật khẩu mới phải có ít nhất 6 ký tự',
                    'pwdNew.max'=>'Mật khẩu mới chỉ được tối đa 30 ký tự',
                    'pwdAgain.required'=>'Bạn chưa nhập lại mật khẩu mới',
                    'pwdAgain.same'=>'Mật khẩu nhập lại không đúng'
                ]);
        $user->password = bcrypt($request->pwdNew);
        }
    

    	$user->save();
		return redirect('admin/user/sua/'.$id)->with('thongbao','Sửa thành công');
    }

    public function getXoa($id){
        $user = User::find($id);
        
        $user->delete();
        return redirect('admin/user/danhsach')->with('thongbao','Xóa thành công');
    }

    public function getDangnhapAdmin(){
    	return view('admin.login');
    }

    public function postDangnhapAdmin(Request $request){
        $this->validate($request,[
         'email'=>'required',
         'password' =>'required|min:3|max:30'
         ],[
         'email.required'=>'Bạn chưa nhập Email',
         'password.required'=>'Bạn chưa nhập Password',
         'password.min'=>'Password không được nhỏ hơn 6 ký tự',
         'password.max'=>'Password không được vượt quá 30 ký tự'
         ]);
        if(Auth::attempt(['email'=>$request->email,'password'=>$request->password])){
            return redirect('index');
        }
        else{
         return redirect('admin/dangnhap')->with('thongbao','Đăng nhập không thành công');
        }
    }
    public function getDangXuatAdmin(){
        Auth::logout();
        return redirect('admin/dangnhap');
    }
    public function index(){
        return view('admin.layout.index');
    }
}