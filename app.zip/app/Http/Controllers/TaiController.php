<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\BaiHat;
use App\Tai;
use Auth;

class TaiController extends Controller
{
    //
    function __construct(){
        $baihat = BaiHat::all();
    	$download = Tai::all();
        $user = User::all();
        view()->share('download',$download);
        view()->share('baihat',$baihat);
        view()->share('user',$user);
    }
   public function getDanhSach(){
    	return view('admin.download.danhsach');
    }
    public function postDownload($id, Request $request){
        $idBaiHat = $id;
        
        $baihat = BaiHat::find($id);
    
        if($baihat->maBaiHat==$id){
            $baihat->luotTai+=1;
            $baihat->save();
        }

       $refreshed=isset($_SERVER['HTTP_CACHE_CONTROL']) && ($_SERVER['HTTP_CACHE_CONTROL'] === 'max-age=0' || $_SERVER['HTTP_CACHE_CONTROL'] == 'no-cache');
        if($refreshed==1){

        }
        else{
            $user = User::find(Auth::user()->id);


            if($user->ngayTai!=$request->ngayTai){
                $user->ngayTai=$request->ngayTai;
                $user->luotTai = 0;
                $user->save();
                }
            else if($user->luotTai<=10){
                $user->luotTai+=1;
                $user->save();    
                }   
            }
        
        
        return redirect("baihat/$id/".$baihat->tenKhongDau.".html")->with('thongbao','Tải thành công');
    }
}
