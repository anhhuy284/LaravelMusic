<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\QuocGia;

class QuocGiaController extends Controller
{
    //
    public function getDanhSach(){
        $quocgia = QuocGia::all();
    	return view('admin.quocgia.danhsach',['quocgia'=>$quocgia]);
    }
    public function getThem(){
    	return view('admin.quocgia.them');	
    }
    public function postThem(Request $request){
        $this->validate($request,[
                'Ten'=>'required|unique:QuocGia,tenQuocGia|min:3|max:100'
            ],
            [
                'Ten.required'=>'Bạn chưa nhập tên quốc gia',
                'Ten.unique'=>'Quốc gia đã tồn tại',
                'Ten.min'=>'Quốc gia phải có độ dài từ 3 => 100 ký tự',
                'Ten.max'=>'Quốc gia phải có độ dài từ 3 => 100 ký tự'
            ]);
        $quocgia = new QuocGia;

        $quocgia->tenQuocGia = $request->Ten;
        $quocgia->tenKhongDau =  changeTitle($request->Ten);

        $quocgia->save();
        return redirect('admin/quocgia/them')->with('thongbao','Thêm thành công');
    }
    public function getSua($id){
        $quocgia = QuocGia::find($id);
    	return view('admin.quocgia.sua',['quocgia'=>$quocgia]);	
    }
    public function postSua(Request $request,$id){
        $quocgia = QuocGia::find($id);
        $this->validate($request,
            [
                'Ten' => 'required|unique:QuocGia,tenQuocGia|min:3|max:100'
            ],
            [
                'Ten.required'=>'Bạn chưa nhập tên quốc gia',
                'Ten.unique'=>'Quốc gia đã tồn tại',
                'Ten.min'=>'Tên quốc gia phải có độ dài từ 3 => 100 ký tự',
                'Ten.max'=>'Tên quốc gia phải có độ dài từ 3 => 100 ký tự'
            ]);
        $quocgia->tenQuocGia = $request->Ten;
        $quocgia->tenKhongDau =  changeTitle($request->Ten);
        $quocgia->save();

        return redirect('admin/quocgia/sua/'.$id)->with('thongbao','Sửa thành công');
    }

    public function getXoa($id){
        $quocgia = QuocGia::find($id);
        $quocgia->delete();

        return redirect('admin/quocgia/danhsach')->with('thongbao','Xóa thành công');
    }
}
