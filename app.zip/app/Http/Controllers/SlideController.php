<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Slide;

class SlideController extends Controller
{
    //
    public function getDanhSach(){
        $slide= Slide::all();
    	return view('admin.slide.danhsach',['slide'=>$slide]);
    }
    public function getThem(){
        $slide= Slide::all();
    	return view('admin.slide.them',['slide'=>$slide]);	
    }
    public function postThem(Request $request)
    {
        $this->validate($request,
            [
                'Ten' => 'required|unique:slide,tenSlide|min:3|max:100'
            ],
            [
                'Ten.required'=>'Bạn chưa nhập tên slide',
                'Ten.unique'=>'Tên slide đã tồn tại',
                'Ten.min'=>'Tên slide phải có độ dài từ 3 => 100 ký tự',
                'Ten.max'=>'Tên slide phải có độ dài từ 3 => 100 ký tự'
            ]);
        $slide = new Slide;

        $slide->tenSlide = $request->Ten;
        $slide->tenKhongDau = changeTitle($request->Ten);
        if($request->hasFile('Hinh'))
        {
            $file = $request->file('Hinh');
            $duoi = $file->getClientOriginalExtension();
            if($duoi != 'jpg' && $duoi != 'png' && $duoi != 'jpeg'){
                return redirect('admin/slide/them')->with('loi','File ảnh không đúng định dạng jpg|png|jpeg.');
            }
            $name = $file->getClientOriginalName();
            $Hinh = str_random(4)."_".$name;
            while(file_exists("upload/slide/".$Hinh)){
                $Hinh = str_random(4)."_".$name;
            }
            $file->move("upload/slide",$Hinh);
            $slide->hinhSlide = $Hinh;
        }
        else
        {
            $slide->hinhSlide = "";
        }

        $slide->save();

        return redirect('admin/slide/them')->with('thongbao','Thêm thành công');

    }
    public function getSua($id){
        $slide = Slide::find($id);
        return view('admin.slide.sua',['slide'=>$slide]);   
    }
    public function postSua(Request $request,$id){
        $slide = Slide::find($id);
        $this->validate($request,
            [
                'Ten' => 'required|min:3|max:100'
            ],
            [
                'Ten.required'=>'Bạn chưa nhập tên tên slide',
                'Ten.min'=>'Tên tên slide phải có ít nhất 3 ký tự',
                'Ten.max'=>'Tên tên slide phải chỉ được tối đa 100 ký tự'
            ]);

        $slide->tenslide = $request->Ten;
        if($request->hasFile('Hinh'))
        {
            if(file_exists("upload/slide/".$slide->hinhSlide)){
                unlink("upload/slide/".$slide->hinhSlide);
            }
            $file = $request->file('Hinh');
            $duoi = $file->getClientOriginalExtension();
            if($duoi != 'jpg' && $duoi != 'png' && $duoi != 'jpeg'){
                return redirect('admin/slide/sua'.$id)->with('loi','File ảnh không đúng định dạng jpg|png|jpeg.');
            }
            $name = $file->getClientOriginalName();
            $Hinh = str_random(4)."_".$name;
            while(file_exists("upload/slide/".$Hinh)){
                $Hinh = str_random(4)."_".$name;
            }
            $file->move("upload/slide",$Hinh);
            $slide->hinhSlide = $Hinh;
        }
        $slide->tenKhongDau = changeTitle($request->Ten);
       
        $slide->save();

        return redirect('admin/slide/sua/'.$id)->with('thongbao','Sửa thành công');
    }

    public function getXoa($id){
        $slide = Slide::find($id);
        if(file_exists("upload/slide/".$slide->hinhSlide)){
                unlink("upload/slide/".$slide->hinhSlide);
            }
        $slide->delete();

        return redirect('admin/slide/danhsach')->with('thongbao','Xóa thành công');
    }
}
