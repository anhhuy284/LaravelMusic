<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\theloais;
use App\QuocGia;
use App\CaSy;

class AjaxController extends Controller
{
    //
    public function getTheLoai($maQuocGia){
        $theloai = theloais::where('maQuocGia',$maQuocGia)->get();
        foreach ($theloai as $tl) {
            echo "<option value='".$tl->maTheLoai."'>".$tl->tenTheLoai."</option>";
        }
    }
    public function getCaSy($maQuocGia){
        $casy = CaSy::where('maQuocGia',$maQuocGia)->get();
        foreach ($casy as $cs) {
            echo "<option value='".$cs->maCaSy."'>".$cs->ngheDanh."</option>";
        }
    }
}
