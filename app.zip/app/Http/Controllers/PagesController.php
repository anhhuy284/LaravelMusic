<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\User;
use App\theloais;
use App\QuocGia;
use App\ChuDe;
use App\Slide;
use App\BaiHat;
use App\CaSy;
use App\ChatLuong;
use App\NhacSi;
use App\Tai;
use App\BinhLuan;
use App\ThongKe;

class PagesController extends Controller
{
    //
    function __construct(){
        
    	$slide = Slide::all();
    	view()->share('slide',$slide);
        $download = Tai::all();
        view()->share('download',$download);
        $quocgia = QuocGia::all();
        view()->share('quocgia',$quocgia);
        $chude = ChuDe::all();
        view()->share('chude',$chude);
        $theloai = theloais::all();
        view()->share('theloai',$theloai);
        $chatluong = ChatLuong::all();
        view()->share('chatluong',$chatluong);
        $casy = CaSy::all();
        view()->share('casy',$casy);
        $NhacSi = NhacSi::all();
        view()->share('NhacSi',$NhacSi);
        $baihat = BaiHat::all();
        view()->share('baihat',$baihat);
        $thongke = ThongKe::all();
        view()->share('thongke',$thongke);
        $bxh = BaiHat::orderBy('luotNghe','desc')->get()->take(10);
        view()->share('bxh',$bxh);
        $this->middleware(function($request,$next){
            if(Auth::check())
            {
                view()->share('user',Auth::user());
            }
            return $next($request);
        });
    }
    function trangchu(){
    	$theloai = theloais::all();
        $baihat = BaiHat::paginate(10);
    	return view('pages.trangchu',['theloai'=>$theloai,'baihat'=>$baihat]);
    }
    
    function thoathuan(){
        return view('pages.thoathuan');
    }
    function google(){
        return Redirect::to('http://www.google.com');
    }
    function theloai($id){
        $theloai = theloais::find($id);
        $baihat = BaiHat::where('maTheLoai',$id)->paginate(5);
        return view('pages.theloai',['theloai'=>$theloai,'baihat'=>$baihat]);
    }
    function baihat($id){
        if(Auth::check())
        {
            $theloai = theloais::find($id);
            $baihat = BaiHat::find($id);
            $baihat1 = BaiHat::orderBy('luotNghe','desc')->get()->take(10);
            $baihatlienquan = BaiHat::where('maTheLoai',$baihat->maTheLoai)->take(5)->get();
            $binhluan = BinhLuan::where('maBaiHat',$id)->get();
            $demBL = count($binhluan);
            $download = Tai::all();
            
            $baihatlienquan = BaiHat::where('maTheLoai',$baihat->maTheLoai)->take(5)->get();

            $refreshed=isset($_SERVER['HTTP_CACHE_CONTROL']) && ($_SERVER['HTTP_CACHE_CONTROL'] === 'max-age=0' || $_SERVER['HTTP_CACHE_CONTROL'] == 'no-cache');
            if($refreshed==1){}
            else{
                $baihat->luotNghe += 1;
                $baihat->save();
            }
            return view('pages.baihat',['baihat'=>$baihat,'baihatlienquan'=>$baihatlienquan,'baihat1'=>$baihat1,'demBL'=>$demBL,'download'=>$download]);
        }
        else
        {
            $binhluan = BinhLuan::where('maBaiHat',$id)->get();
            $demBL = count($binhluan);

            $theloai = theloais::find($id);
            $baihat = BaiHat::find($id);
            $baihat1 = BaiHat::all();
            $baihatlienquan = BaiHat::where('maTheLoai',$baihat->maTheLoai)->take(5)->get();

            $refreshed=isset($_SERVER['HTTP_CACHE_CONTROL']) && ($_SERVER['HTTP_CACHE_CONTROL'] === 'max-age=0' || $_SERVER['HTTP_CACHE_CONTROL'] == 'no-cache');
            if($refreshed==1){

            }
            else{
                $baihat->luotNghe += 1;
                $baihat->save();
            }
            $download = Tai::all();
            return view('pages.baihat',['baihat'=>$baihat,'baihatlienquan'=>$baihatlienquan,'baihat1'=>$baihat1,'demBL'=>$demBL,'download'=>$download]);
        }

         
    }
    function casy($id){
        if(Auth::check())
        {
            $casy = CaSy::find($id);
            $theloai = theloais::find($id);
            $baihat = BaiHat::find($id);
            $baihat1 = BaiHat::all();
            //$baihatlienquan = BaiHat::where('maCaSy',$baihat->maCaSy)->take(5)->get();
            //$baihatlienquan = BaiHat::where('maTheLoai',$baihat->maTheLoai)->take(5)->get();
            
            return view('pages.casy',['baihat'=>$baihat,'baihat1'=>$baihat1,'casy'=>$casy]);
        }
        else
        {
            $casy = CaSy::find($id);
            $theloai = theloais::find($id);
            $baihat = BaiHat::find($id);
            $baihat1 = BaiHat::all();
            //$baihatlienquan = BaiHat::where('maTheLoai',$baihat->maTheLoai)->take(5)->get();

            return view('pages.casy',['baihat'=>$baihat,'baihat1'=>$baihat1,'casy'=>$casy]);
        }
    }

    function getDangNhap(){
        return view('pages.dangnhap');
    }

    function postDangNhap(Request $request){
        
        $this->validate($request,[
         'email'=>'required',
         'password' =>'required|min:3|max:30'
         ],[
         'email.required'=>'Bạn chưa nhập Email',
         'password.required'=>'Bạn chưa nhập Password',
         'password.min'=>'Password không được nhỏ hơn 6 ký tự',
         'password.max'=>'Password không được vượt quá 30 ký tự'
         ]);
            
        if(Auth::attempt(['email'=>$request->email,'password'=>$request->password])){
            $user = User::find(Auth::user()->id);
            if($user->ngayTai!=date('d')){
                $user->ngayTai = date('d');
                $user->luotTai = 0;
                $user->save();
            }
            else{
            }
            return redirect('trangchu');
        }
        
        else{
         return redirect('dangnhap')->with('thongbao','Đăng nhập không thành công');
        }
    }
    public function getDangXuat(){
        Auth::logout();
        return redirect('trangchu');
    }
    function getDangKy(){
        return view('pages.dangky');
    }

    function postDangKy(Request $request){
        $this->validate($request,
            [
                'name' => 'required|unique:users,username|min:6|max:30',
                'pwd' => 'required|min:6|max:30',
                'pwdAgain' => 'required|same:pwd',
                'Email' => 'required|email|unique:users,email'
            ],
            [
                'name.required'=>'Bạn chưa nhập Username',
                'name.unique'=>'User đã tồn tại',
                'name.min'=>'Username phải có ít nhất 6 ký tự',
                'name.max'=>'Username tối đa 30 ký tự',
                'pwd.required'=>'Bạn chưa nhập password',
                'pwd.min'=>'Password phải có ít nhất 6 ký tự',
                'pwd.max'=>'Password tối đa 30 ký tự',
                'pwdAgain.required' =>'Bạn chưa nhập password xác nhận',
                'pwdAgain.same' =>'Password xác nhận không đúng',
                'Email.required'=>'Bạn chưa nhập email',
                'Email.email'=>'Email không đúng. Vui lòng kiểm tra lại',
                'Email.unique'=>'Email đã được sử dụng. Vui lòng dùng địa chỉ Email khác'
            ]);
        $user = new User;

        $user->username = $request->name;
        $user->password = bcrypt($request->pwd);
        $user->email = $request->Email;
        $user->name = $request->Ten;
        $user->level = 2;


        $user->save();
        return redirect('dangnhap')->with('thongbao','Chúc mừng bạn đã đăng ký thành công');
    }
    function timkiem(Request $request){
        if(!is_null($request->tukhoa)){

            $tukhoa = $request->tukhoa;
            $baihat = BaiHat::where('tenBaiHat','like',"%$tukhoa%")->take(30)->paginate(5);
            $casy = CaSy::where('ngheDanh','like',"%$tukhoa%")->take(30)->simplePaginate(5);
            $dem = count($baihat);
            $demcs = count($casy);
            $baihat1 = BaiHat::orderBy('luotNghe','desc')->get()->take(10);
            
            return view('pages.timkiem',['baihat'=>$baihat,'tukhoa'=>$tukhoa,'dem'=>$dem,'demcs'=>$demcs,'casy'=>$casy,'baihat1'=>$baihat1]);
        }
        else{
            
             return redirect('trangchu')->with('loi','Vui lòng nhập từ khóa');
        }
    }

    function getNguoiDung(){
        return view('pages.nguoidung');
    }
    function postNguoiDung(Request $request){
        $user = Auth::user();
        $user->name = $request->name;
         if($request->changePwd == "on"){
            $this->validate($request,[
                    'pwdNew' => 'required|min:6|max:30',
                    'pwdAgain' => 'required|same:pwdNew',
                ],[
                    'pwdNew.required'=>'Bạn chưa nhập mật khẩu mới',
                    'pwdNew.min'=>'Mật khẩu mới phải có ít nhất 6 ký tự',
                    'pwdNew.max'=>'Mật khẩu mới chỉ được tối đa 30 ký tự',
                    'pwdAgain.required'=>'Bạn chưa nhập lại mật khẩu mới',
                    'pwdAgain.same'=>'Mật khẩu nhập lại không đúng'
                ]);
        
                $user->password = bcrypt($request->pwdNew);
            }

        $user->save();
        return redirect('nguoidung')->with('thongbao','Thay đổi thành công');
    }

    function getUpload(){
        return view('pages.uploadBaiHat');
    }
    function postUpload(Request $request){
        $this->validate($request,
            [
                'Ten' => 'required|unique:BaiHat,tenBaiHat|min:3|max:30'
            ],
            [
                'Ten.required'=>'Bạn chưa nhập tên bài hát',
                'Ten.unique'=>'Bài hát đã tồn tại',
                'Ten.min'=>'Tên ca sỹ phải có ít nhất 3 ký tự',
                'Ten.max'=>'Tên ca sỹ chỉ được phép tối đa 30 ký tự'
            ]);
        $baihat = new BaiHat;

        $baihat->tenBaiHat = $request->Ten;
        $baihat->maQuocGia = $request->QuocGia;
        $baihat->maChatLuong = $request->ChatLuong;

        $baihat->maCaSy = $request->CaSy;

        $baihat->maTheLoai = $request->TheLoai;
        $baihat->ngayDang = $request->NgayDang;
        $baihat->id = Auth::user()->id;
        $baihat->tenKhongDau =  changeTitle($request->Ten);

        if($request->hasFile('DuongDan'))
        {
            $file = $request->file('DuongDan');
            
            $duoi = $file->getClientOriginalExtension();
            $kichthuoc = $file->getClientSize();
            
            if($kichthuoc >= 15728640)
                return redirect('uploadBaiHat')->with('loi','Lỗi. File upload vượt quá 8MB');

            if($duoi != 'mp3')
                return redirect('uploadBaiHat')->with('loi','File bài hát không đúng định dạng mp3');

            $name = $file->getClientOriginalName();
            $Hinh = str_random(4)."_".str_replace($name, str_random(10).".".$duoi, $name);
            while(file_exists("upload/baiHat/".$Hinh)){
                $Hinh = str_random(4)."_".str_replace($name, str_random(10).".".$duoi, $name);
            }
            $file->move("upload/baiHat",$Hinh);
            $baihat->duongDan = $Hinh;
        }

        $baihat->save();
        return redirect('uploadBaiHat')->with('thongbao','Upload thành công');
    }

    
}
