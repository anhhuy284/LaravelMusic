<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\theloais;
use App\QuocGia;

class TheLoaiController extends Controller
{
    //
    public function getDanhSach(){
        $theloai= theloais::all();
        $quocgia = QuocGia::all();
    	return view('admin.theloai.danhsach',['theloai'=>$theloai,'quocgia'=>$quocgia]);
    }
    public function getThem(){
        $quocgia= QuocGia::all();
    	return view('admin.theloai.them',['quocgia'=>$quocgia]);	
    }
    public function postThem(Request $request)
    {
        $this->validate($request,
            [
                'Ten' => 'required|unique:TheLoai,tenTheLoai|min:3|max:100',
                'QuocGia' => 'required'
            ],
            [
                'Ten.required'=>'Bạn chưa nhập tên thể loại',
                'Ten.unique'=>'Tên thể loại đã tồn tại',
                'Ten.min'=>'Tên thể loại phải có độ dài từ 3 => 100 ký tự',
                'Ten.max'=>'Tên thể loại phải có độ dài từ 3 => 100 ký tự',
                'QuocGia.required'=>'Bạn chưa chọn Quốc gia'
            ]);
        $theloai = new theloais;

        $theloai->tenTheLoai = $request->Ten;
        $theloai->tenKhongDau = changeTitle($request->Ten);
        $theloai->maQuocGia = $request->QuocGia;

        $theloai->save();

        return redirect('admin/theloai/them')->with('thongbao','Thêm thể loại thành công');

    }
    public function getSua($maTheLoai){
        $theloai = theloais::find($maTheLoai);
        return view('admin.theloai.sua',['theloai'=>$theloai]);   
    }
    public function postSua(Request $request,$id){
        $theloai = theloais::find($id);
        $this->validate($request,
            [
                'Ten' => 'required|unique:TheLoai,tenTheLoai|min:3|max:100'
            ],
            [
                'Ten.required'=>'Bạn chưa nhập tên thể loại',
                'Ten.unique'=>'Tên thể loại đã tồn tại',
                'Ten.min'=>'Tên thể loại phải có độ dài từ 3 => 100 ký tự',
                'Ten.max'=>'Tên thể loại phải có độ dài từ 3 => 100 ký tự'
            ]);
        $theloai->tenTheLoai = $request->Ten;
        $theloai->save();

        return redirect('admin/theloai/sua/'.$id)->with('thongbao','Sửa thành công');
    }

    public function getXoa($id){
        $theloai = theloais::find($id);
        $theloai->delete();

        return redirect('admin/theloai/danhsach')->with('thongbao','Xóa thành công');
    }
}
