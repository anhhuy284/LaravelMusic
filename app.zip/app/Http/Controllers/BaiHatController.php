<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\BaiHat;
use App\QuocGia;
use App\theloais;
use App\ChuDe;
use App\CaSy;
use App\NhacSi;
use App\ChatLuong;
use Auth;

class BaiHatController extends Controller
{
    //
    function __construct(){
        $quocgia = QuocGia::all();
        $chude =ChuDe::all();
        $chatluong=ChatLuong::all();
        $casy = CaSy::all();
        $nhacsi = NhacSi::all();
        $theloai= theloais::all();
        $baihat = BaiHat::all();
        view()->share('quocgia',$quocgia);
        view()->share('chude',$chude);
        view()->share('chatluong',$chatluong);
        view()->share('nhacsi',$nhacsi);
        view()->share('casy',$casy);
        view()->share('theloai',$theloai);
        view()->share('baihat',$baihat);
    }
    public function getDanhSach(){
    	return view('admin.baihat.danhsach');
    }
    public function getThongKe(){
        return view('admin.thongke.danhsach');
    }
    public function getThem(){

    	return view('admin.baihat.them');
    }
    
    public function postThem(Request $request){
        $this->validate($request,
            [
                'Ten' => 'required|unique:BaiHat,tenBaiHat|min:3|max:100'
            ],
            [
                'Ten.required'=>'Bạn chưa nhập tên bài hát',
                'Ten.unique'=>'Bài hát đã tồn tại',
                'Ten.min'=>'Tên ca sỹ phải có độ dài từ 3 => 100 ký tự',
                'Ten.max'=>'Tên ca sỹ phải có độ dài từ 3 => 100 ký tự'
            ]);
        $baihat = new BaiHat;

        $baihat->tenBaiHat = $request->Ten;
        $baihat->maQuocGia = $request->QuocGia;
        $baihat->maChuDe = $request->ChuDe;
        $baihat->maChatLuong = $request->ChatLuong;
        $baihat->maCaSy = $request->CaSy;
        $baihat->maNhacSi = $request->NhacSi;
        $baihat->maTheLoai = $request->TheLoai;
        $baihat->loiBaiHat = $request->LoiBaiHat;
        $baihat->ngayDang = $request->NgayDang;
        $baihat->id = Auth::user()->id;
        $baihat->tenKhongDau =  changeTitle($request->Ten);
        $file =$request->DuongDan;
        //  if($request->hasFile('DuongDan'))
        // {
        //     $file = $request->file('DuongDan');
            
        //     $duoi = $file->getClientOriginalExtension();
        //     $kichthuoc = $file->getClientSize();
            
        //     if($kichthuoc >= 8388608)
        //         return redirect('admin/baihat/them')->with('loi','Lỗi. File upload vượt quá 8MB');

        //     if($duoi != 'mp3')
        //         return redirect('admin/baihat/them')->with('loi','File bài hát không đúng định dạng mp3');

        //     $name = $file->getClientOriginalName();
        //     $Hinh = str_random(4)."_".str_replace($name, str_random(10).".".$duoi, $name);
        //     while(file_exists("upload/baiHat/".$Hinh)){
        //         $Hinh = str_random(4)."_".str_replace($name, str_random(10).".".$duoi, $name);
        //     }
        //     $file->move("upload/baiHat",$Hinh);
        //     $baihat->duongDan = $Hinh;
            
        // }
            
        $baihat->duongDan = 'tyzV_XGeRIyHIK1.mp3';
        $baihat->save();
        return redirect('admin/baihat/them')->with('thongbao','Thêm thành công');
    }
    public function getSua($id){
        $baihat = BaiHat::find($id);
        return view('admin.baihat.sua',['baihat'=>$baihat]);    
    }
    public function postSua($id, Request $request){
        $baihat = BaiHat::find($id);

        $this->validate($request,
            [
                'Ten' => 'required|min:3|max:100'
            ],
            [
                'Ten.required'=>'Bạn chưa nhập tên bài hát',
                'Ten.min'=>'Tên ca sỹ phải có độ dài từ 3 => 100 ký tự',
                'Ten.max'=>'Tên ca sỹ phải có độ dài từ 3 => 100 ký tự'
            ]);

        $baihat->tenBaiHat = $request->Ten;
        $baihat->maChuDe = $request->ChuDe;
        $baihat->maNhacSi = $request->NhacSi;
        $baihat->loiBaiHat = $request->LoiBaiHat;
        $baihat->tenKhongDau =  changeTitle($request->Ten);
        $baihat->save();

    	return redirect('admin/baihat/sua/'.$id)->with('thongbao','Sửa thành công');	
    }
    public function getXoa($id){
        $baihat = BaiHat::find($id);
        
        if(file_exists("upload/baiHat/".$baihat->duongDan)){
            unlink("upload/baiHat/".$baihat->duongDan);
        }
        $baihat->delete();
        return redirect('admin/baihat/danhsach')->with('thongbao','Xóa thành công');
    }
}
