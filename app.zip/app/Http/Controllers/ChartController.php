<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ChartController extends Controller
{
	public function generatecharts()
	{

		$lava = new Lavacharts;
		$stocksTable = Lava::DataTable();
	    $stocksTable->addDateColumn('Day of Month')
	        ->addNumberColumn('Projected')
	        ->addNumberColumn('Official');

	    // Random Data For Example
	    for ($a = 1; $a < 30; $a++) {
	        $stocksTable->addRow(["2014-8-$a", rand(800, 1000), rand(800, 1000)]);
	    }

	    $Chart = Lava::LineChart('this_is_the_label', $stocksTable, [
	        'title'    => 'This works in laravel 5.2',
	        'fontSize' => 24,
	    ]);

		return view('admin.thongke.danhsach');

	}
}