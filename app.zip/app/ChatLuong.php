<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChatLuong extends Model
{
    //
    protected $table = "ChatLuong";
    protected $primaryKey ="maChatLuong";
    public $timestamps = false;
}
