<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QuocGia extends Model
{
    //
	protected $table = "QuocGia";
	protected $primaryKey ="maQuocGia";
	public function theloai()
	{
		return $this->hasMany('App\theloais','maQuocGia');
	}
	public function baihat(){
		return $this->hasManyThrough('App\BaiHat','App\theloais','maQuocGia','maTheLoai','maBaiHat');
	}
}
