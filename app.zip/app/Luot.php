<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Luot extends Model
{
    //
    protected $table = "Luot";
    protected $primayKey = "idLuot";
}
